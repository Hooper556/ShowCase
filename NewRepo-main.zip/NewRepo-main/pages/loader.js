export default function Loader() {
  return (
    <div>
      <p>Loading</p>
    </div>
  );
}
